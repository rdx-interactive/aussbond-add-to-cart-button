# Changelog

## 1.0.0 - 2026-05-22

- Initial production release.
- Added Elementor widget `Aussbond Add to Cart Button`.
- Added support for WooCommerce simple and variable products.
- Added variation attribute dropdowns, quantity selection, AJAX add-to-cart, WooCommerce notices, mini-cart fragment refreshes, and Elementor style controls.
- Added nonce, input sanitization, output escaping, variation validation, stock validation, and duplicate-submission throttling.
- Hardened activation compatibility by lazy-loading the Elementor widget class and avoiding PHP 8-only syntax in the bootstrap path.
